package com.ticket.booking.reserve.controller;

import com.ticket.booking.reserve.model.Ticket;
import com.ticket.booking.reserve.service.BookingTicketService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ArunKumar.Sugumar
 */
@RestController
@RequestMapping(value = "/ticket")
public class BookingController {

    private final BookingTicketService bookingTicketService;

    public BookingController(BookingTicketService bookingTicketService) {
        this.bookingTicketService = bookingTicketService;
    }

    @PostMapping(value = "/reserve")
    public Integer reserveTicket(@PathVariable("showId") int showId,
                                 @PathVariable("numberOfSeats") int numberOfSeats) {

        //Todo: Call ticket availability service check tickets are available
        // and avoid concurrent booking of same seat. Will be handled in different service.

        //Todo: Call discount service to avail offers
        return bookingTicketService.reserveTicket(showId, numberOfSeats);
    }

    @GetMapping(value = "/ticket/{bookingId}")
    public Ticket getTicket(@PathVariable int bookingId) {

        return bookingTicketService.getTicket(bookingId);
    }
}

package com.ticket.booking.reserve.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

/**
 * @author ArunKumar.Sugumar
 */
@Getter
@Setter
public class Ticket {

    private int bookingId;
    private String movieName;
    private String screen;
    private LocalTime start_time;
    private String theatre;
    private String city;

}

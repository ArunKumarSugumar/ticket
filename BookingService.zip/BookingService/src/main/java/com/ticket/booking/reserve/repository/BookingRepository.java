package com.ticket.booking.reserve.repository;

import com.ticket.booking.reserve.model.Ticket;

/**
 * @author ArunKumar.Sugumar
 */
public interface BookingRepository {

    int save(int showId, int numberOfSeats);

    Ticket getTicket(int bookingId);
}

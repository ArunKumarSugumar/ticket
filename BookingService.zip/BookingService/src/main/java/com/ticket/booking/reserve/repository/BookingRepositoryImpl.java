package com.ticket.booking.reserve.repository;

import com.ticket.booking.reserve.model.Ticket;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;

/**
 * @author ArunKumar.Sugumar
 */
@Repository
@Transactional
public class BookingRepositoryImpl implements BookingRepository {

    private final JdbcTemplate jdbcTemplate;

    public BookingRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int save(int showId, int numberOfSeats) {

        return jdbcTemplate.update("insert into booking values ",
                numberOfSeats, Timestamp.from(Instant.now()), "CONFIRMED", 1, showId);

    }

    @Override
    public Ticket getTicket(int bookingId) {
        return jdbcTemplate.queryForObject("select m.title as movie_name, b.booking_id, s.name as screen, sh.start_time, \n" +
                        "c.name as theatre, ct.name as city\n" +
                        "from booking b, show sh, movie m, screen s, cinema c, city ct where b.booking_id = ?" +
                        "and sh.show_id = b.show_id\n" +
                        "and sh.movie_id = m.movie_id\n" +
                        "and sh.screen_id = s.screen_id\n" +
                        "and s.cinema_id = c.cinema_id\n" +
                        "and c.city_id = ct.city_id", new Object[]{bookingId},
                (rs, rowNum) -> {
                    Ticket ticket = new Ticket();
                    ticket.setBookingId(rs.getInt("booking_id"));
                    ticket.setCity(rs.getString("city"));
                    ticket.setScreen(rs.getString("screen"));
                    ticket.setTheatre(rs.getString("theatre"));
                    ticket.setMovieName(rs.getString("movie_name"));
                    ticket.setStart_time(rs.getTime("start_time").toLocalTime());

                    return ticket;
                });
    }
}

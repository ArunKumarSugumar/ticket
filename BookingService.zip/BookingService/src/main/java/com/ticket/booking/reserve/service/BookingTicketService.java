package com.ticket.booking.reserve.service;

import com.ticket.booking.reserve.model.Ticket;

/**
 * @author ArunKumar.Sugumar
 */
public interface BookingTicketService {

    int reserveTicket(int showId, int numberOfSeats);

    Ticket getTicket(int bookingId);
}

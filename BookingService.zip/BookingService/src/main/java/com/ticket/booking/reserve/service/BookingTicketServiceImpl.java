package com.ticket.booking.reserve.service;

import com.ticket.booking.reserve.model.Ticket;
import com.ticket.booking.reserve.repository.BookingRepository;
import org.springframework.stereotype.Service;

/**
 * @author ArunKumar.Sugumar
 */
@Service
public class BookingTicketServiceImpl implements BookingTicketService {

    private final BookingRepository bookingRepository;

    public BookingTicketServiceImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public int reserveTicket(int showId, int numberOfSeats) {

        return bookingRepository.save(showId, numberOfSeats);
    }

    @Override
    public Ticket getTicket(int bookingId) {
        return bookingRepository.getTicket(bookingId);
    }
}

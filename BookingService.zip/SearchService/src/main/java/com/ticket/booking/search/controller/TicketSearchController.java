package com.ticket.booking.search.controller;

import com.ticket.booking.search.model.Cinema;
import com.ticket.booking.search.model.Search;
import com.ticket.booking.search.service.CinemaSearchService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @author ArunKumar.Sugumar
 */
@RestController
@RequestMapping(value = "/ticket")
public class TicketSearchController {

    private final CinemaSearchService cinemaSearchService;

    public TicketSearchController(CinemaSearchService cinemaSearchService) {
        this.cinemaSearchService = cinemaSearchService;
    }

    @PostMapping(value = "/search")
    public Map<String, List<Cinema>> postSearch(@RequestBody Search search) {

        // returns theatres with list of shows running for a movie
        return cinemaSearchService
                .findCinemasInCityByMovieName(search.getCityId(), search.getMovie());
    }
}

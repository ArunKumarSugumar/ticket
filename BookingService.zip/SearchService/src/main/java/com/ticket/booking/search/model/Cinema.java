package com.ticket.booking.search.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author ArunKumar.Sugumar
 */

@Getter
@Setter
public class Cinema {

    private int cinemaId;
    private String cinemaName;
    private Show show;
}

package com.ticket.booking.search.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

/**
 * @author ArunKumar.Sugumar
 */
@Getter
@Setter
public class Search {

    private int cityId;
    private String movie;
}

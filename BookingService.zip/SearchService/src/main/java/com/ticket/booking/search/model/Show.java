package com.ticket.booking.search.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * @author ArunKumar.Sugumar
 */
@Getter
@Setter
public class Show {

    private int showId;
    private String screenName;
    private LocalTime startTime;
    private LocalDate showDate;
}

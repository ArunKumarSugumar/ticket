package com.ticket.booking.search.repository;

import com.ticket.booking.search.model.Cinema;

import java.util.List;

/**
 * @author ArunKumar.Sugumar
 */
public interface CinemaRepository {

    List<Cinema> findCinemasInCityByMovieName(int cityId, String movieName);
}

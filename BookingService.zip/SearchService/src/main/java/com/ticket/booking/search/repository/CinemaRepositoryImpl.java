package com.ticket.booking.search.repository;

import com.ticket.booking.search.model.Cinema;
import com.ticket.booking.search.model.Show;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author ArunKumar.Sugumar
 */
@Repository
@Transactional
public class CinemaRepositoryImpl implements CinemaRepository {

    private final JdbcTemplate jdbcTemplate;

    public CinemaRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Cinema> findCinemasInCityByMovieName(int cityId, String movieName) {

        return jdbcTemplate.query("select c.cinema_id, c.name as cinema_name, s.name as screen_name, " +
                        "sh.show_id, sh.show_date, sh.start_time " +
                        "from cinema c, screen s, show sh, movie m where c.city_id = ? " +
                        "and m.title like ? " +
                        "and s.cinema_id = c.cinema_id " +
                        "and s.screen_id = sh.screen_id " +
                        "and m.movie_id = sh.movie_id ", new Object[]{cityId, "%" + movieName + "%"},
                (rs, rowNum) -> {

                    Cinema cinema = new Cinema();
                    cinema.setCinemaId(rs.getInt("cinema_id"));
                    cinema.setCinemaName(rs.getString("cinema_name"));

                    Show show = new Show();
                    show.setShowId(rs.getInt("show_id"));
                    show.setScreenName(rs.getString("screen_name"));
                    show.setStartTime(rs.getTime("start_time").toLocalTime());
                    show.setShowDate(rs.getDate("show_date").toLocalDate());

                    cinema.setShow(show);

                    return cinema;

                });

    }
}

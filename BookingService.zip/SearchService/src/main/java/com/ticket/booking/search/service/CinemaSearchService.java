package com.ticket.booking.search.service;

import com.ticket.booking.search.model.Cinema;

import java.util.List;
import java.util.Map;

/**
 * @author ArunKumar.Sugumar
 */
public interface CinemaSearchService {

    Map<String, List<Cinema>> findCinemasInCityByMovieName(int cityId, String movieName);
}

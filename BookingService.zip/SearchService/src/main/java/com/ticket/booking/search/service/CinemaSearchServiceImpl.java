package com.ticket.booking.search.service;

import com.ticket.booking.search.model.Cinema;
import com.ticket.booking.search.repository.CinemaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ArunKumar.Sugumar
 */
@Service
public class CinemaSearchServiceImpl implements CinemaSearchService {

    private final CinemaRepository cinemaRepository;

    public CinemaSearchServiceImpl(CinemaRepository cinemaRepository) {
        this.cinemaRepository = cinemaRepository;
    }

    @Override
    public Map<String, List<Cinema>> findCinemasInCityByMovieName(int cityId, String movieName) {

        return cinemaRepository
                .findCinemasInCityByMovieName(cityId, movieName)
                .stream()
                .collect(Collectors.groupingBy(Cinema::getCinemaName));
    }
}
